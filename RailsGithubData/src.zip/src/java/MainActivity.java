package io.github.riyanshkarani011235.railsgithubdata;

import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.io.InputStream;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    // public variables
    static String url = "https://api.github.com/repos/ruby/ruby/comments?page=";
    static ArrayList<Comment> commentsArrayList = new ArrayList<Comment>();
    static Activity this_;
    static ListView listView;
    static int pageNumber = 1;
    static boolean loadingComplete = false;
    static QueryUrl queryUrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this_ = this;
        listView = (ListView) findViewById(R.id.list_view);

        // check network info
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        if(!(networkInfo != null && networkInfo.isConnected())) {
            Toast.makeText(this, "Network Connection not available", Toast.LENGTH_SHORT).show();
            this_.finish();
        } else {
            // restore previous saved instance state if one exists
            if (savedInstanceState != null) {
                loadingComplete = savedInstanceState.getBoolean("loadingComplete");
            } else {
                Toast.makeText(this_, "Fetching data", Toast.LENGTH_SHORT).show();
            }

            getData();
        }
    }

    public static void makeToast(String toastString) {
        Toast.makeText(this_, toastString, Toast.LENGTH_SHORT).show();
    }

    public static void getData() {
        if (!loadingComplete) {
            Log.i("queryUrl", url+pageNumber);
            queryUrl = new QueryUrl(url + pageNumber);
            queryUrl.execute();
        } else {
            updateLayout();
            ProgressBar progressBar = (ProgressBar) this_.findViewById(R.id.loading_panel);
            progressBar.setVisibility(View.GONE);
        }
    }

    public static void updateComments(ArrayList<Comment> commentArrayListAppend) {
        if(commentArrayListAppend != null) {
            commentsArrayList.addAll(commentArrayListAppend);
            updateLayout();
            if (commentArrayListAppend.size() != 0) {
                pageNumber += 1;
                getData();
            } else {
                ProgressBar progressBar = (ProgressBar) this_.findViewById(R.id.loading_panel);
                progressBar.setVisibility(View.GONE);
                loadingComplete = true;
            }
        } else {
            if (queryUrl.responseStatus == 403) {
                makeToast("API rate limit (60) exceeded for this hour. Wait for an hour or switch to another network.");
                loadingComplete = true;
                ProgressBar progressBar = (ProgressBar) this_.findViewById(R.id.loading_panel);
                progressBar.setVisibility(View.GONE);
                if(commentsArrayList.size() == 0) {
                    this_.finish();
                }
            }
        }
    }

    public static void updateLayout() {
        if (commentsArrayList.size() == 0) {
            // pass
        } else {
            CommentsAdapter adapter = new CommentsAdapter(this_, commentsArrayList);
            listView.setAdapter(adapter);
        }
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        savedInstanceState.putBoolean("loadingComplete", loadingComplete);
    }
}
