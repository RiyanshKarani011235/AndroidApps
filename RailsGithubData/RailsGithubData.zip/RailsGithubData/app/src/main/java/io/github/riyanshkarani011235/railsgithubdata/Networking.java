package io.github.riyanshkarani011235.railsgithubdata;

import android.util.Log;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Stack;

/**
 * Created by ironstein on 22/08/16.
 */
public class Networking {

    // private variables
    private URL mUrl;
    private InputStream mInputStream;

    // public variables
    int responseStatus = 200;

    public void Networking() {}

    public InputStream setupConnection(String urlString) {
        /*
         * Get an `InputStream` corresponding to a `HttpURLConnection` for the url `urlString`
         *
         * Args :
         *      urlString -- a valid urlString
         *
         * Returns :
         *      an `InputStream` object for accessing data from the `HttpURLConnection`
         */

        // public variables
        int connectionTimeout = 10000; // milliseconds
        int readTimeout = 15000; // milliseconds

        try {
            mUrl = new URL(urlString);

            try {
                // initialize connection
                HttpURLConnection connection = (HttpURLConnection) mUrl.openConnection();

                // setup connection
                connection.setConnectTimeout(connectionTimeout);
                connection.setReadTimeout(readTimeout);
                connection.setRequestMethod("GET");
                connection.setDoInput(true);

                // start the query
                try {
                    connection.connect();
                    int response = connection.getResponseCode();

                    if (response == 200) {
                        // OK
                        mInputStream = connection.getInputStream();
                        return mInputStream;

                    } else if (response == 401) {
                        // Unauthorized
                        responseStatus = 401;
                        Log.e("Networking.setupConn...", "unauthorized HttpURL connection");
                    } else if (response == 403) {
                        responseStatus = 403;
                    } else {
                        // no response code
                        Log.e("Networking.setupConn...", "could not discern response code : " + response);
                    }
                } catch (java.io.IOException e) {
                    Log.e("Networking.setupConn...", "error connecting");
                }


            } catch (java.io.IOException e) {
                Log.e("Networking.setupConn...", "unable to open HTTP Connection");
            }
        } catch (java.net.MalformedURLException e) {
            Log.e("Networking.setupConn..", "malformed url " + urlString);
        }

        // if could not get InputStream
        return null;
    }

    public String getStringFromInputStream() {
        BufferedReader br = null;
        StringBuilder sb = new StringBuilder(5000000);
        String line;

        try {
            br = new BufferedReader(new InputStreamReader(mInputStream));
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
        } catch (java.io.IOException e) {
            Log.e("BufferReader(new ..)", e.toString());
            return null;
        } finally {
            if(br != null) {
                try {
                    br.close();
                }catch (java.io.IOException e) {
                    Log.e("br.close", e.toString());
                }
            }
        }
        return createValidJsonString(sb.toString());

    }

    public String createValidJsonString(String string) {

        int indexOfLastParen = 0;
        Stack<Integer> parenIndices = new Stack<Integer>();
        String returnString = "";
        for(int i=0; i<string.length(); i++) {
            if (string.charAt(i) == "{".charAt(0)) {
                parenIndices.push(new Integer(i));
            } else if(string.charAt(i) == "}".charAt(0)) {
                parenIndices.pop();
            }
        }
        if(parenIndices.empty()) {
            // correct Json string
            return string;
        } else {
            // incorrect Json string
            for(int i=0; i<parenIndices.get(0).intValue();i++) {
                returnString += string.charAt(i);
            }
            return returnString;
        }

    }

    public void closeInputStream() {
        try {
            if (mInputStream != null) {
                mInputStream.close();
            }
        } catch (java.io.IOException e) {
            // pass
        }
    }
}
