package io.github.riyanshkarani011235.railsgithubdata;

import android.os.AsyncTask;
import android.util.Log;

import java.io.InputStream;
import java.util.ArrayList;

/**
 * Created by ironstein on 22/08/16.
 */
public class QueryUrl extends AsyncTask<String, Void, String> {

    // private variables
    private String mUrlString;
    private InputStream mInputStream;
    private String mJsonData;
    private ArrayList<Comment> mCommentsArrayList;

    // public variables
    int responseStatus;

    public QueryUrl(String urlString) {
        mUrlString = urlString;
    }

    public String doInBackground(String... params) {
        Networking networking = new Networking();
        mInputStream = networking.setupConnection(mUrlString);
        responseStatus = networking.responseStatus;

        if (mInputStream != null) {

            // get json data
            mJsonData = networking.getStringFromInputStream();
            mCommentsArrayList = Comment.createCommentsArray(mJsonData);
        }

        networking.closeInputStream();
        return null;
    }

    protected void onPostExecute(String params) {
        MainActivity.updateComments(mCommentsArrayList);
    }

}
