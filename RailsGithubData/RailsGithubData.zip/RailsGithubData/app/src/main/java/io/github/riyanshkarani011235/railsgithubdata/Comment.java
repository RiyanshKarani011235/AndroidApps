package io.github.riyanshkarani011235.railsgithubdata;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by ironstein on 22/08/16.
 */
public class Comment {

    private String mAuthorName;
    private String mCommentBody;
    private String mTimeCreated;
    private String mTimeModified;
    private String mUrl;

    public Comment(String authorName, String commentBody, String timeCreated, String timeModified, String url) {
        mAuthorName = authorName;
        mCommentBody = commentBody;
        mTimeCreated = timeCreated;
        mTimeModified = timeModified;
        mUrl = url;
    }

    public String toString() {
        String returnString = "author : " + mAuthorName + "\n";
        returnString += "body : " + mCommentBody + "\n";
        returnString += "time created : " + mTimeCreated + "\n";
        returnString += "time modified : " + mTimeModified + "\n";
        returnString += "url : " + mUrl;
        return returnString;
    }

    // getters
    public String getAuthorName() {
        return mAuthorName;
    }

    public String getCommentBody() {
        return mCommentBody;
    }

    public String getTimeCreated() {
        return mTimeCreated;
    }

    public String getTimeModified() {
        return mTimeModified;
    }

    public String getUrl() {
        return mUrl;
    }

    public static ArrayList<Comment> createCommentsArray(String jsonString) {
        ArrayList<Comment> commentsArray = new ArrayList<Comment>();
        try {
            JSONArray jsonArray = new JSONArray(jsonString);
            for (int i=0; i<jsonArray.length(); i++) {
                commentsArray.add(createComment(jsonArray.getJSONObject(i)));
            }
        } catch (org.json.JSONException e) {
            Log.e("createCommentsArray", e.toString());
        }
        return commentsArray;
    }

    public static Comment createComment(JSONObject jsonObject) {
        String authorName;
        String commentBody;
        String timeCreated;
        String timeModified;
        String url;

        // authorName
        try {
            authorName = jsonObject.getJSONObject("user").getString("login");
        } catch (org.json.JSONException e) {
            authorName = "not available";
        }

        // commentBody
        try {
            commentBody = jsonObject.getString("body");
        } catch (org.json.JSONException e) {
            commentBody = "not available";
        }

        // timeCreated
        try {
            timeCreated = jsonObject.getString("created_at");
        } catch (org.json.JSONException e) {
            timeCreated = "not available";
        }

        // timeModified
        try {
            timeModified = jsonObject.getString("updated_at");
        } catch (org.json.JSONException e) {
            timeModified = "not available";
        }

        // url
        try {
            url = jsonObject.getString("html_url");
        } catch (org.json.JSONException e) {
            url = null;
        }

        return new Comment(authorName, commentBody, timeCreated, timeModified, url);
    }
}
