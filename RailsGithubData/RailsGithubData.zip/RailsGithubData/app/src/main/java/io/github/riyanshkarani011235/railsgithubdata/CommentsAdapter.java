package io.github.riyanshkarani011235.railsgithubdata;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by ironstein on 22/08/16.
 */
public class CommentsAdapter extends ArrayAdapter<Comment> {

    public CommentsAdapter(Activity context, ArrayList comments) {
        super(context, 0, comments);
    }

    public class ViewHolder {
        TextView authorName;
        TextView body;
        TextView timeCreated;
        TextView timeModified;
        Button redirectButton;
        String url;
    }

    ViewHolder viewHolder = new ViewHolder();

    public View getView(int position, View convertView, ViewGroup parent) {
        View commentView = convertView;

        if(commentView == null) {
            // inflate new view
            commentView = LayoutInflater.from(getContext()).inflate(R.layout.comment_card, parent, false);

            // initialize viewHolder
            viewHolder = new ViewHolder();
            viewHolder.authorName = (TextView) commentView.findViewById(R.id.author_name);
            viewHolder.body = (TextView) commentView.findViewById(R.id.body);
            viewHolder.timeCreated = (TextView) commentView.findViewById(R.id.time_created);
            viewHolder.timeModified = (TextView) commentView.findViewById(R.id.time_modified);
            viewHolder.redirectButton = (Button) commentView.findViewById(R.id.redirect_button);
            commentView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) commentView.getTag();
        }

        final Comment comment = getItem(position);
        viewHolder.authorName.setText(comment.getAuthorName());
        viewHolder.body.setText(comment.getCommentBody());
        viewHolder.timeCreated.setText(comment.getTimeCreated());
        viewHolder.timeModified.setText(comment.getTimeModified());

        // if this card is clicked, open the github page for this comment
        viewHolder.redirectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(comment.getUrl()));
                getContext().startActivity(intent);
            }
        });

        return commentView;

    }

}
